
import telebot
import requests
import os

TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Link yuboring, men sizga faylni qaytaraman.")

@bot.message_handler(func=lambda message: message.text and message.text.startswith("http"))
def handle_url(message):
    url = message.text.strip()
    try:
        file_data = requests.get(url, stream=True)
        filename = url.split("/")[-1] or "file"
        with open(filename, "wb") as f:
            for chunk in file_data.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)
        with open(filename, "rb") as f:
            bot.send_document(message.chat.id, f, caption=f"Yuklab olindi: {filename}")
        os.remove(filename)
    except Exception as e:
        bot.reply_to(message, f"Xatolik: {e}")

bot.polling()
